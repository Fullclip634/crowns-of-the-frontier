import test from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from 'three';
import {contactPose} from '../src/visual-depth.js';

test('terrain-aligned contact shadows stay attached to moving units while stationary scenery reuses its pose',()=>{
  let samples=0;const view={contactDummy:new THREE.Object3D(),groundHeight:(x,z)=>{samples++;return x*.05+z*.1;}},entity={id:7};
  const first=contactPose(view,entity,3,5,2);const afterFirst=samples;assert.ok(first.matrix.elements.every(Number.isFinite));assert.equal(first.matrix.elements[12],3);assert.equal(first.matrix.elements[14],5);assert.ok(Math.abs(first.matrix.elements[13]-.685)<.0001);
  for(let i=0;i<60;i++)assert.equal(contactPose(view,entity,3,5,2),first);assert.equal(samples,afterFirst,'idle objects do not repeatedly resample static terrain');
  const moved=contactPose(view,entity,4,8,2);assert.notEqual(moved,first);assert.equal(moved.matrix.elements[12],4);assert.equal(moved.matrix.elements[14],8);assert.ok(samples>afterFirst);
  const larger=contactPose(view,entity,4,8,3);assert.notEqual(larger,moved);assert.ok(Math.abs(larger.matrix.determinant())>Math.abs(moved.matrix.determinant()));
  view.contactCache=new Map();view.groundHeight=()=>9;const changedMap=contactPose(view,entity,4,8,3);assert.ok(Math.abs(changedMap.matrix.elements[13]-9.035)<.0001);
});
