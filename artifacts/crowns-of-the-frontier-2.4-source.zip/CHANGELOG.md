# Kingdoms and skies (version 2.4)

- Rooted near-detail trees, solid winter snowcaps, wind movement, harvested tree falls and persistent stumps. Batched 3D cargo follows villagers, ore visibly shrinks with depletion, and town-center architecture gains physical features at each age. Stronger playable terrain relief, huge-map grass/fog coverage, allied animated gates, and observed multiplayer work animations.
- Coastal armies stay on their current shore, scout capitals before repeated harbor foundations, search cleared settlements, rebuild harbors with paid workers, reserve fleet population, prioritize transport replacement, fill balanced invasion crews, retry voyages, and choose flanking landing sites around observed defenses.
- Free single-service Render deployment configuration, health checks and a short deployment guide; optional Netlify static builds with a separate secure multiplayer endpoint and exact frontend origin permissions. Leaving now cancels pending reconnect attempts.
- Health, carried-resource and production timer updates preserve existing buttons and portrait canvases, preventing live updates from interrupting touch training or cancellation. Hosted connection errors stay visible in the multiplayer dialog.

- Configurable custom battles with two to eight kingdoms, human or AI slots, civilizations, teams, individual AI difficulties and six team/free-for-all presets.
- Huge 400 × 400 maps by default, plus 320 × 320 and 240 × 240 options. Navigation, fog, terrain picking, camera limits, minimap and rendering support the larger battlefield and eight army colors.
- Default victory requires all opposing buildings, including walls and foundations. Optional capital and total-conquest rules, capital rebuilding, public final-building markers, alliance results and defeat spectating.
- Authoritative mixed human/AI multiplayer, slot choice, readiness gating, per-team visibility, private economies, ownership, compressed compact snapshots, disconnect pauses, reconnect recovery and concessions that preserve surviving teams.
- Seeded weather transitions, volumetric rain/snow/clouds and splash rings, wet terrain/light changes, optional lightning, independent weather audio, reduced-motion support and quality budgets.
- Sustained AI attacks across large maps, independent planning, remembered-target cleanup and paid market trade for shortages. AI gathers and pays for armies, buildings and upgrades.
- Physical tree/ore navigation and construction obstacles, final-load delivery after resources run out, cached vision/movement regions, valid-route retention and bounded blocked-path retries.
- Low quality renders at up to 30 FPS; menu and hidden-tab rendering is throttled. Fresh settings choose Low on modest reported hardware, and unseen objects defer mesh allocation. Real-device FPS and balance remain separate release validation requirements.
- Expanded automated, browser and long-match diagnostics cover custom setup, eight real WebSocket clients, phone layouts, weather, ownership, reconnects, alliances, late-game progression and full-building elimination.

# Movement display update

- Removed selected-unit movement and queued-route lines on desktop and phones, including the route-display setting. Movement, patrol, guard, and queued commands remain available.

# Frontier chronicles (version 2.3)

- Three staged objectives per campaign chapter, original dialogue journals, optional medals, and active minimap/3D goal markers.
- Supply-caravan mesh model and guarded river escort with an explicit loss condition. Select-caravan and locate-goal controls are available in the objective panel.
- Frozen initial and stage checkpoints, commander-menu and defeat-screen recovery, local save/resume, and legacy rules for existing campaign saves.
- Settlement, fortress, shrine-control/conquest, siege-breach, and coastal landing/artillery chapter flows. Fishing objectives count deposited boat catch.
- Objective updates preserve scrolling/focus and expose interactive controls without triggering camera edge scrolling. Phone recovery controls and compact technology-tree layouts receive browser coverage.
- Exact waypoint arrival and island-aware naval regrouping reduce the coastal diagnostic run from 74 blocked orders to four. Remaining bridge/crowding cases still need review.
- Regression coverage includes normal economy/production, real escort navigation, shrine holding, paid naval artillery, actual gate attacks, actor loss, and checkpoint recovery.

This continues the playable beta roadmap. External balance and mission-pacing tests, real-device rendering performance, richer authored assets/audio, public online operations, and overall world-class parity remain unfinished.

# Commanders and kingdoms (version 2.2)

- Saved remappable keys with conflict/reserved-key validation, updated shortcut labels, and active bindings in Help.
- Patrol/guard orders, network ownership checks, queued-order summaries, and bounded 3D route previews. Routes follow terrain and stay visible above water for ships.
- Legal formation destinations, correct partial-path arrival checks, blocked-order feedback/recovery, axis sliding near obstacles, and safer automatic naval target selection.
- Paid strategic AI with planned economy/production, observed enemy memory, counters, age-resource reserves, repairs, retreats, healer escorts, scouting, and transport boarding reservations.
- Alder sentinels, Sunward marksmen, and Raven outriders with solid 3D model variants, costs, prerequisites, and counters. Shield drill, Caravan ledger, and Raiding parties add civilization-specific research.
- Interactive technology tree with faction comparison and eligible training/research. Older saves initialize added research fields.
- Higher-contrast interface, reduced decorative motion, larger tactical touch controls, and saved route preferences.
- Expanded simulation, graphics, control, strategy, save, and real-WebSocket regression coverage. New commander browser and passive-player AI soak scripts write reviewable artifacts.

This is a tested development milestone. Public matchmaking, replay/spectator services, richer authored campaigns, production-quality assets/audio, measured physical-device targets, independent balance testing, and overall world-class parity remain unverified or unfinished. Naval blocked-order cases remain under review.

# Realm in depth — version 2.1

## Radar and production controls

- Square minimap at desktop, tablet, and phone sizes. A rectangular camera locator replaces the irregular perspective polygon; a center dot makes location readable when zoomed out. The rectangle encloses the visible ground and updates while scrolling, zooming, and rotating.
- Mouse and touch dragging on the minimap, accurate curved waterways and bridges, visible ship/resource icons, and orders restricted to playable terrain with reachable edge coordinates.
- Fog matches the terrain triangulation at every quality setting.
- Production overview (P or the top-bar button) shows active/idle buildings, units, research, age advancement, progress, and cancel/refund controls. Select a production building to locate it or select a whole building type.
- Queue refreshes preserve panel scrolling and keyboard focus, including short landscape phone layouts.
- Train across several selected buildings, balancing requests by remaining queue time. Shift-click queues up to five; phones have +5 buttons. Resource, population, ownership, age, and queue limits remain enforced, including authoritative multiplayer requests.
- Nine additional automated checks cover radar geometry, boundaries, batch distribution, budget limits, network request planning, and saved production queues. Browser scripts exercise laptop/phone radar and production controls.

## Mouse camera controls

- Mouse edge scrolling enabled by default on all four viewport edges and diagonal corners, with directional cursor arrows and camera-relative movement.
- Saved toggle and speed control in Settings; stops over controls, during menus and pauses, on blur/viewport exit, and for touch input or middle-button dragging.
- Construction previews follow the cursor while edge scrolling moves the terrain beneath it.
- Browser verification covers eight directions, rotated views, stopping conditions, settings persistence, and touch protection.

- Rebuilt all 19 building models and all 14 troop/ship/sovereign models, with faction architecture, solid folded sails and banners, shaped humanoids and horses, and articulated limbs, wheels, oars, rams, and trebuchets.
- Rebuilt trees, ore deposits, fruit, fish, and shrines as volumetric models.
- Replaced flat ground and cone-shaped map borders with seeded terrain and ridges. Picking, actors, foundations, fog, construction previews, and effects follow the triangulated terrain surface.
- Moving water vertices, submerged naval basins, dry bridges, lifting gate portcullises, construction scaffolds/clipping, and actual 3D building previews.
- Live WebGL selection portraits, object inspection on mouse/touch, closer perspectives, and a button to hide battlefield panels.
- Visible forests pack into near/far instanced batches with solid geometry at both detail levels. Camera obstruction handling, efficient crop geometry, bounded portrait refresh, and cleanup between maps.
- Five additional graphics checks cover all model types/civilizations, terrain determinism, surface picking, bridge/sea elevations, model bounds, batching, and skeletal motion. Browser coverage exercises every biome, naval rendering, live portraits, inspection, and landscape phone controls.

# Frontiers & fleets — version 2.0

## Visual depth update

- A closer default perspective and three selectable camera angles, with visible rotate/zoom buttons, V shortcut, two-finger touch rotation, and saved camera preferences.
- More directional light, procedural environment illumination, camera-centered shadow coverage, and shared contact shadows that remain available with dynamic shadows disabled.
- Surface relief on masonry, timber, and roofs; separate roof and troop materials; aligned gables; raised timber framing, windows, eaves, and entry steps; smoother heads and shaped torsos.
- Browser checks cover camera buttons, picking after rotation, persisted settings, actual two-finger touch events, and contact shadows in Performance quality.

## Gameplay

- Two-player Wi-Fi rooms with five victory rules, mirrored starting forces, private player economies, per-player fog, command ownership checks, and session reconnection.
- Naval conquest, a divided-coast map, and a sixth campaign chapter.
- Shoreline harbors, fishing boats with actual catch deposits, galleys, siege galleons, and eight-passenger transports.
- Embarking, disembarking, passenger loss when a transport sinks, naval navigation, ship production, and seamanship research.
- Tactical AI responds to observed cavalry/archers, defends its base, repairs buildings, escorts attacks with healers, manages fishing, and ferries invasion forces.

## Presentation and performance

- Articulated legs, arms, weapons, and working villagers through instanced model parts.
- Rocking ships, ship wakes, animated water, harbor jetties, gabled roofs, textured materials, and rounded forest canopies.
- Exploration controls forest visibility. Hidden units are not included in multiplayer opponent snapshots.
- Layered impacts, arrows, siege sounds, stereo placement, birds, wind, and music. Effect counts and audio voices are bounded.
- Heap-based pathfinding, indexed entity lookup, broader collision checks, cached animation transforms, and interpolated network movement.
- Selected-unit combat attributes, clear transport unloading controls, room codes, and phone-compatible room menus.

## Validation

- Automated simulation and real WebSocket tests cover economy, queues, ages, research, combat, walls, victory rules, save compatibility, naval mechanics, player ownership, fog masking, fair starts, and reconnect pauses.
- Browser QA covers naval controls and a live desktop/landscape-phone match, phone troop training, and reconnection after a reload.
- Hardware performance and game balance still need broader real-device and human playtesting. This release does not establish commercial AAA parity.
