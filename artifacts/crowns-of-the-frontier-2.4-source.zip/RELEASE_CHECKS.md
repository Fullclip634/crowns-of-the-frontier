# Version 2.4 verification

Checked 10 October 2026. This records observed checks, rather than a claim that all possible bugs or all device configurations have been ruled out.

## Automated game checks

`npm test`: **118 passed, zero failed**. Coverage includes paid gathering/construction/training/research; ages and civilization restrictions; counters, healing and siege; walls, gates and bridges; fleets and transports; all modes and staged campaigns; checkpoints and save compatibility; production batches; custom alliances, large-map fog/navigation/picking, each victory rule, independent AI clocks, seeded weather, real WebSocket rooms, shore-aware invasion targets, fleet population reserves, visible work animations, solid cargo/tree transforms, secure hosted endpoints and canceled reconnect timers.

Eight simultaneous real WebSocket clients exercised readiness, private economies and fog, command ownership, reconnect recovery, host elimination and alliance results. Mixed human/AI rooms also passed. These tests use isolated services and do not modify live player rooms.

## Custom battle and 3D checks

`scripts/custom-battle-qa.mjs` passed in a real Edge renderer with desktop and emulated landscape-phone layouts:

- Huge 400 × 400 battlefield, eight kingdoms, independent AI difficulty and eight army materials.
- Actual terrain clicks beyond the former ±160 picking limit and full-map radar navigation.
- Deferred unseen-mesh allocation, persistent objective scrolling/rules, and custom save/resume with a paid training queue.
- Volumetric rain with three effect draw calls; quality-limited snow, weather settings and optional lightning.
- Square minimap, touch interaction and no horizontal page overflow at 844 × 390.

`scripts/custom-multiplayer-qa.mjs` passed with desktop and phone-sized browsers, a third real WebSocket commander and an AI kingdom: guest slot choice, host/guest readiness, private local perspectives, rejected foreign commands, phone production, reload/rejoin, host defeat without ending the match, and correct alliance victory/defeat.

The machine reports approximately 4 GB RAM. Three simultaneous 3D browser contexts timed out without a JavaScript error; a later two-renderer run also timed out during startup. The current mixed-room check keeps two browser connections, suspends rendering in the background desktop host, actively renders the landscape-phone client, and connects a third real WebSocket commander. This is not a simultaneous multi-device FPS measurement. Failed attempts remain recorded in the browser report. A reconnect assertion was corrected to count both queued and completed paid units in the received resume state, because production can finish while a cold browser redraws.

`scripts/interactions-qa.mjs` passed actual harvesting, carried logs/sacks/ingots/rocks, tree falls and persistent stumps, ore depletion, one-time town-center model replacement per age change, huge-map fog/grass coverage and landscape-phone camera interaction. The scene contains no sprites. Four repeated Huge winter matches held GPU counts at **245 geometries and 11 textures** in this fixture. Cargo/stumps used at most five extra draw calls. This follows Three.js's [explicit resource disposal guidance](https://threejs.org/manual/pages/how-to-dispose-of-objects.html) and [mesh batching guidance](https://threejs.org/manual/pages/optimize-lots-of-objects.html).

## Full-match diagnostic

`scripts/battle-benchmark.mjs`, seed 512, Huge highlands, eight Hard AI kingdoms, standard resources and an 80-person cap:

- Started with the normal economy. The diagnostic alone assigned AI control to the normal human slot.
- All kingdoms reached Imperial Age. The winning alliance eliminated every opposing building through normal production and combat, finishing at **977.4 simulated seconds** (about 16 minutes).
- CPU-only simulation tick times: median **10.44 ms**, p95 **21.24 ms**, p99 **30.10 ms**, maximum **65.68 ms** on this run. These are simulation timings, not rendered FPS or phone timings.
- An earlier pre-optimization match also reached a normal result after about 29 simulated minutes. Battle length is situational, without a forced minimum timer.

Recorded artifacts include `artifacts/battle-benchmark-highlands.json`, the earlier baseline/pre-route-cache reports, custom browser JSON reports and screenshots.

The expanded coastal audit initially exposed stalled cross-shore orders, repeated harbor losses and fleet recruitment starvation. After the fixes, the eight-Hard-AI Huge coast diagnostic reached normal all-building victory at **1138.8 simulated seconds** (about 19 minutes), with all kingdoms reaching Imperial Age. It used standard starting resources, paid production and actual combat. The earlier fleet-fix run also reached victory at 778.5 seconds; flanking strategy changed the final battle's course. The final report is `artifacts/battle-benchmark-coast.json`, with failed/stalled earlier runs retained separately. It ran alongside browser checks on this low-memory machine: median tick 12.86 ms, p95 73.86 ms and a 2.51-second maximum under contention. These timings are not a standalone performance baseline or evidence of smooth phone FPS.

## Corrections made during the audit

Corrected outer-map picking, resource/harbor overlap, coastal resource access, final-load delivery after deposits/shoals are exhausted, sustained AI attack orders, final-building visibility for AI, naval boarding reservations, individual AI ownership/budgets, private research/error notices and objective scroll resets. Added straight-route checks, connected movement regions, reusable path buffers, valid-route retention, blocked-order retry limits, vision indexing and shared composition calculations. Low quality and background/menu rendering budgets reduce work; saved graphics preferences remain respected.

Further corrections include harbor rebuilding without free resources, market trade recovery at the real price threshold, current-shore army orders and retreats, legal capital scouting, searches after clearing a capital, canceled-voyage retries, formation-safe unloading beside occupied harbors, reserved fleet population, transport replacement priority, fuller siege/healer invasion crews and flanking shores chosen from observed defenses. Cargo now uses current interpolated unit positions; town-center age metadata survives batching, and allied units open modeled gate portcullises.

Live selected-object health/cargo and production countdowns now update in place. Production buttons and portrait canvases remain attached until the selection or available actions change, avoiding interrupted taps when a network snapshot updates the UI. A browser regression checks the actual training-button identity across health/timer changes while its health text and queue progress continue updating.

## Hosting preparation

The included `render.yaml` selects one **Free** Node web service in Singapore, with a health check and one simultaneous room for the small server. No expiring database or paid service is provisioned. `netlify.toml` also supports a static frontend with an optional separate secure multiplayer URL and exact server origin permissions. See [DEPLOYMENT.md](DEPLOYMENT.md) for the short setup and verified provider limits. No public site has been deployed from this workspace.

`scripts/deployment-qa.mjs` passed two isolated production builds: static solo/custom play, readable unavailable-multiplayer notices, no broken socket attempts and offline reload; then a separate frontend/backend with a configured endpoint, accepted exact origin and real WebSocket room creation. Offline manifests now follow the configured build output directory rather than accidentally using another build's assets. The report is `artifacts/deployment-qa.json`.

## Further release evidence

Ten broader browser checks and the affected reruns passed: edge scrolling, square radar, production, commander controls/tactics/technology tree, campaign checkpoint flows, solid 3D models across biomes, world interactions, custom setup/weather, offline reload/play, and custom multiplayer. The consolidated report is `artifacts/release-browser-checks.json`; failed attempts are preserved in each affected check's history. The final production/multiplayer rerun is also in `artifacts/production-stability-checks.json`. The running server was restarted with the final source after verifying that no player connections were active; its HTTP version 2.4 bundle, WebSocket ping and hosting health check passed at the laptop and Wi-Fi address. See `artifacts/live-server-check.json`. The current local addresses are `http://localhost:4173/` and `http://192.168.1.6:4173/` on the same Wi-Fi.

Physical phone/laptop FPS, sustained thermal/memory behavior, human balance and mission pacing, and delayed/lossy network play still need independent testing. Public matchmaking, persistent server rooms, accounts, professional authored assets and voice acting are outside this implemented local release. The game is an original playable RTS beta; commercial AAA parity or “100% world class” has not been established.
