# Blender art and runtime rendering

The deployed game includes both GLB catalogues and texture files. Playing or deploying it requires no Blender installation and no external asset service.

The catalogue contains 126 models: 66 civilization/age building variants, 18 troop/ship/caravan types plus four worker task variants, 24 forest variants and 14 resource models. The models were made for this original game. They are not Age of Empires or Warcraft assets.

## Edit and regenerate

The development installation uses Blender 4.5.14 LTS at `.tools/blender-4.5.14-windows-x64/blender.exe`. The editable generated project is `.tools/art-refined/frontier-assets.blend`. Open the current catalogue showcase with:

```powershell
powershell -ExecutionPolicy Bypass -File scripts/blender/start.ps1 -Visible -Showcase
```

`scripts/blender/showcase.py` arranges the catalogue for inspection with material colors. The live browser applies the photographed surfaces, lighting, fog and weather. The lightweight Blender preview disables expensive viewport modifiers for this laptop.

```powershell
npm run art:build
npm run art:materials
npm run build
```

`art:build` exports the original model source, refines it in background Blender, creates adult-proportioned figures and solid worker tools, then compresses near/low GLBs with gltfpack. Bevels, baked vertex shading, normals, UVs and semantic material/joint metadata survive export. The builder runs jobs sequentially to limit memory pressure. Blender and gltfpack are development tools in `.tools`; they are excluded from deployment archives. Blender's [published minimum is 8 GB RAM](https://www.blender.org/download/requirements/), above this laptop's approximately 4 GB, so large art tasks need care.

`art:materials` downloads four CC0 surface sets using the published Poly Haven API and verifies file sizes and hashes, reusing only verified local files. Runtime uses local bundled JPEGs, with no asset API requests. Creator credits and source links are in [the texture license](src/assets3d/textures/LICENSE.md).

On another computer, install Blender and gltfpack and set `BLENDER_BIN` and `GLTFPACK_BIN` to their executable paths before `art:build`. Normal deployment builds use the supplied GLBs and JPEGs directly.

## In-game behavior and budgets

- The near GLB is 15,554,824 bytes (14.83 MiB); the lower detail GLB is 3,639,276 bytes (3.47 MiB). Both contain the full 126-model catalogue. Twelve photographed surface maps total 9,895,943 bytes (9.44 MiB). The declared low-catalogue content budget is now 4 MiB to retain the added architecture and equipment; this is a download budget, not an FPS achievement.
- High uses near geometry and color/normal/roughness maps. Medium uses low geometry with color/normal maps. Low uses low geometry and color maps.
- Covered civic arcades, front steps, facade arches, gable windows and civilization-specific roof details strengthen building silhouettes. Painted-plaster color, normal and roughness maps join the grass, wood and masonry sets.
- Adult figures include villager field packs and armored visors. Local unit positions interpolate between simulation ticks and turn smoothly without changing authoritative positions or saves. Multiplayer interpolation is bounded to its snapshot interval.
- Nested joint metadata drives runtime poses. The catalogue does not contain baked skeletal animation clips. Worker tools follow their actual gathering/building/repair task.
- Curved tapering trunks and branching bends support distinct oak, birch, elm and beech crown proportions. High includes sixteen smaller crown lobes with pointed closed leaf tips; the tips are excluded from the smaller phone catalogue. Winter forests have branched boughs and irregular snow patches. Bark grain and muted, varied canopy colors add surface detail. Runtime tree detail follows projected screen size.
- Bows use distinct draw/release/recovery poses, melee uses a striking arm with a steadier off hand, and firing intervals come from each unit's real cooldown.
- Arrows and siege shots start at terrain-aligned weapon heights and turn along their flight arc. Reusable meshes bound repeated combat allocation. Active cosmetic effects are released when changing scenes; they do not change simulation damage or attack timing.
- Troops share instanced batches across team colors. Visible instance IDs are packed together so picking and selection still identify the correct unit. Fog and offscreen culling reduce submitted instances.
- Buildings merge static surfaces into one opaque draw, with shared geometry for repeat structures. Flags, windmills, gates and harbor piers retain their independent transforms. Construction clipping preserves the textured material shader.
- Batched roofs retain their shared tile texture and per-owner colors, including the lighter model catalogue. Roof normals use the actual mesh rather than a wall's normal map.
- Water waves displace the actual mesh on the GPU with analytical slope normals and expanded culling bounds. They retain the earlier wave profile without uploading geometry or recalculating face normals each frame. `scripts/water-visual-qa.mjs` checks visible lighting changes, both presets, unchanged CPU geometry and disposal on scene changes.
- Terrain banks meet water level at the naval channel boundary rather than dipping below the sea outside navigable water. View-angle-dependent sky tint replaces the conspicuous scrolling stripe map. This is a lightweight lighting approximation, not a full reflection of other scene objects.
- Fine moving ripple normals add small highlights between the larger mesh waves, with lower intensity on Low. Water is treated as a dielectric surface rather than metal. Water-only pixel probes exclude ships, fish and foliage so their movement cannot pass the wave check.
- Solid grass uses one instanced draw and clears building foundations. Fallen units and flying/settling rubble are cosmetic, bounded and excluded from collision, orders and saves.
- The square radar, HUD and text remain interface overlays. The playable world and selectable objects use solid 3D meshes.
- Artwork loading requires every manifest model and offers a retry on failure. Production pages check the current build and offer a saved solo refresh; an active human multiplayer match blocks refreshing until leaving the room. Existing pages from before this feature need one normal refresh first.

Use `scripts/blender/start.ps1 -Visible -Showcase -LowPreview` for the actual lighter catalogue in Blender when authoring and gameplay would otherwise compete for memory. It saves a separate `frontier-showcase-low.blend`; the detailed editable source and the High runtime catalogue remain available.

`tests/authored-assets.test.js`, `tests/render-batches.test.js`, `tests/ground-cover.test.js`, `tests/battle-effects.test.js` and `tests/battle-remains.test.js` check catalogue coverage, outward leaf volumes, bounds, joints, tools, ownership, packing, foundations and effect limits. `scripts/authored-art-qa.mjs` reviews the live renderer, camera/selection preservation, biomes, naval models and emulated landscape-phone controls. `scripts/battle-visual-qa.mjs` captures close forests and checks live projectile arcs, pool reuse and scene-switch memory. Rendering targets and actual measured limitations are recorded separately in [RELEASE_CHECKS.md](RELEASE_CHECKS.md).
