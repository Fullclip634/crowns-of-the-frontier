# Version 2.5 verification

Checked 11 October 2026. This is a tested development build; the high-load performance and external playtesting requirements below remain release blockers.

## Latest quality work

The latest source/build pass adds civic arcades and facade details, worker packs and armored visors, species-shaped broadleaf crowns, photographed plaster, local movement interpolation, required-art retry and saved update notices. Both catalogues have all 126 models; their current sizes are 15,554,824/3,639,276 bytes. Twelve surface JPEGs total 9,895,943 bytes. The low-catalogue download budget is explicitly 4 MiB. The complete automated suite passes **153 checks, zero failures**, including bank heights matching actual naval navigation boundaries. The network timer fixture isolates perspective remapping from the normal gameplay reset of uncaptured sacred-site counters. Eight relevant art checks pass again after fixing batched roof textures. The older 149-check performance results below predate this pass and must not be treated as measurements of the new assets.

Current production Edge checks pass both catalogues, all seven biomes, naval models, working tools, picking/team colors, bounded remains, camera preservation and emulated landscape touch with no browser errors. High startup takes 10.6 seconds in this run; the settlement fixture uses 218 draws and 1,131,379 triangles. Close High forests/projectiles compile with no shader errors and retain 146 geometries/18 textures through repeated combat. Focused checks deliberately fail the artwork download, verify a usable retry, prove current civic/figure revisions and textured roof/plaster surfaces, sample movement between ticks without changing simulation positions, save before updating, and block refresh in a real human room. Reports: `artifacts/authored-art-qa.json`, `artifacts/battle-visual-qa.json`, `artifacts/visual-updates-qa.json`. These are functional/visual checks, not sustained frame-rate or physical-device certification.

The subsequent GPU-water check passes on High/Low: the same physical wave profile moves highlights across the sampled water pixels while CPU vertex/normal versions remain unchanged, and old water geometry is disposed on scene changes. Culling bounds include the wave amplitude. This eliminates that animation's per-frame geometry uploads; it is not proof of a 60 FPS achievement. `artifacts/water-visual-qa.json` records the live shader result.

The latest crowded-scene sample before GPU water measured High **13.48 FPS**, 305 draws and 1,958,126 triangles at 1280 x 720. A Low repeat after the GPU-water source measured **12.24 FPS**, 294 draws and 399,532 triangles in a 5.065-second window. Both miss the selected 60 FPS target; this highlands fixture contains no water, so it cannot measure that optimization. The preceding Low sample stalled for roughly 21 seconds with a 14-second tick; it is retained separately and should not be used as a stable quality comparison. Reports: `artifacts/performance-before-gpu-water.json`, `artifacts/performance-civic-stalled-low.json`, `artifacts/performance-qa.json`. Sustained optimization and reference-device validation remain open.

### Earlier checks before the civic and figure redesign

The laptop's earlier 12 FPS result is a constrained stress measurement, not the development target or a definition of acceptable graphics. [QUALITY_TARGETS.md](QUALITY_TARGETS.md) keeps the full art, animation, gameplay, missions, controls, sound, multiplayer and device goals explicit. Desktop/gaming-laptop rendering targets 60 FPS and primary-touch devices target 30 FPS, with saved 30/60 choices independent of Low/Medium/High graphics. Deadline-based frame pacing avoids accidentally halving a 60 FPS target on fractional display ticks. Automatic quality uses the selected frame budget.

The latest full automated run passes **149 checks**. The regenerated 126-model Blender catalogues retain their complete roster; curved/tapered trunks, closed broadleaf tips, varied canopy shading, bark grain and branched winter foliage with patchy snow improve forest detail. Extra broadleaf tip meshes are excluded from the smaller phone catalogue. Tree detail follows projected screen size. Near/low GLBs are 13,753,532/3,093,656 bytes. Live Blender-art checks pass all seven biomes, naval models, saved frame-rate choice, 3D picking, team colors, camera/selection preservation and landscape touch without browser errors. The updated settlement fixture submits 218 draws and approximately 862,000 triangles; richer foliage adds geometry, and this count is not a frame-rate achievement.

Ranged soldiers now use bow draw/release/recovery poses rather than melee swings; real unit cooldowns preserve firing intervals. Working villagers have a steadier off hand. Observed multiplayer workers use their public work activity/resource type to choose the same physical tools and poses as local workers, without revealing private orders.

Solid projectiles start at terrain/interpolation-aligned weapon heights and rotate along their flight arc. Live combat-effects checks verify reuse, bounded retained objects, cleanup during scene switches and a stable 146-geometry/14-texture count over the repeated attack fixture. These cosmetic effects preserve authoritative damage/timing. Idle contact shadows reuse cached terrain poses.

The live CPU profile identified ownership queries, joint animation and graphics buffer work among remaining costs. Unit/building queries now narrow candidates while preserving immediate death/ownership changes, spawning and snapshot restoration. Packed troop, forest, contact and cover matrices upload only their used prefix; unchanged troop ownership avoids repeated color uploads. The late fixture requests 103,424 bytes of troop matrices per frame instead of its 5,939,200-byte allocated capacity. This is upload-range evidence, not an FPS guarantee.

An isolated replay of the same earlier late battle logged **23 blocked orders before** retreat/formation recovery and **1 after**, while reaching normal victory. The remaining order came from the restored legacy retreat state before a new AI decision. Destination reservations keep corrected formation slots distinct around buildings; injured troops, recalled support and coastal regrouping use groups instead of repeated overlapping rally points. This demonstrates improvement in that replay, not universal route completion. Reports: `artifacts/navigation-before-formations.json` and `artifacts/navigation-audit.json`.

All ten earlier refreshed browser scenarios pass across `artifacts/latest-quality-browser-checks.json` and `artifacts/latest-extra-browser-checks.json`. The final production Blender-art check passes after partial uploads: both catalogues, all seven biomes, team colors/picking, tool changes, quality switching and landscape touch, without browser errors. Combat visual coverage is in `artifacts/battle-visual-qa.json`. The remaining interaction/offline checks are refreshed separately. Prior baseline results below retain their dates and scope.

The latest fresh eight-Hard-AI Huge coastal battle reaches normal all-building team victory at 1276.3 simulated seconds (about 21 minutes), with 165 allied-support events. Six kingdoms reach Imperial Age; two are defeated at Castle Age. First land offensives occur at 169.3-230.5 seconds from the coastal Feudal start, while naval launches occur at 168.1-712.2 seconds. Paid economy/production and transport warfare remain active. CPU tick median/p95 is 4.68/14.24 ms in the offline diagnostic. There are still 547 blocked orders across the kingdoms, so route recovery remains open even though the match reaches legitimate victory. Report: `artifacts/battle-benchmark-coast.json`. This is simulation evidence, not human difficulty or rendered-FPS certification.

## Earlier automated and visual evidence

- Production build succeeds; `npm test` passes **149 checks, zero failures**. Coverage includes the economy/combat/campaign/network baseline, Blender roster/leaf volumes/tools/joints, pooled projectile arcs/reuse, shared colors/picking/upload ranges, building bounds/cache/construction/moving pivots, solid cover/remains, frame pacing/automatic quality, eligible drop-off recovery, live ownership queries, formations and allied support/recall.
- Eight real WebSocket clients pass private team perspective, readiness, command ownership, reconnect, host defeat and alliance results. Support notices reach teammates only and have correctly remapped owners. AI alarm data is removed from every client snapshot.
- `scripts/authored-art-qa.mjs` passes live Edge checks: both 126-model Blender catalogues, actual jobs switching tools without duplicate figures, animated parts, 3D picking, team colors in shared batches, bounded bodies/rubble, seven biomes, naval models, quality switching with preserved camera/selection, and landscape touch layout. No browser errors were recorded.
- At 844 x 390, the tested selection panel is 110 pixels high, primary touch controls are at least 44 pixels tall and the radar is a 96 x 96 square. This is browser emulation, not physical phone certification.
- The updated settlement fixture uses **218 draw calls**, compared with **483** before troop/building batching. It retains the solid models and photographed surfaces. Actual crowded-battle measurements are reported separately below.
- The local production server serves version **2.5.0**. HTTP, WebSocket ping and `/health` pass. Its current Wi-Fi play address is **http://192.168.1.3:4173/**; the laptop address is **http://localhost:4173/**. The server was refreshed after verifying no clients were connected.
- All ten production-browser checks pass: edge scrolling, radar, production, commander/technology controls, staged campaigns, 3D biomes, world interactions, custom setup/pacing/weather, offline play and mixed human/AI multiplayer. The phone Home control was moved above the radar after a test found it intercepted map taps. Portrait-transition and grass-coverage assertions were updated for the new renderer. Failed attempts are retained in `artifacts/release-browser-2.5-checks.json`.
- Offline verification confirms both Blender GLBs and all nine surface maps are cached and solo gameplay starts after an offline reload.
- Static-host solo/custom/offline play and a separate frontend/backend multiplayer deployment pass against the current build. The static frontend reports unavailable multiplayer without attempting a broken socket; the configured frontend connects to the isolated authoritative server through its explicitly allowed origin. Record: `artifacts/deployment-qa.json`.
- Versioned source and static ZIPs were created and inspected: both include two GLBs and nine JPEG maps; the static ZIP has a root `index.html`; local tools, dependencies and private environment files are excluded. The actual 126-model Blender showcase was opened and visually inspected through the native connector.

## Balanced AI full match

`scripts/battle-benchmark.mjs`, seed 512, Huge highlands, eight Hard AI kingdoms, standard resources, 80-person caps and Balanced pacing reached normal all-building victory after **1214.3 simulated seconds** (about 20 minutes). Every kingdom reached Imperial Age. Major land offensives began between **240.8 and 311.6 seconds**; defense and allied support remained active beforehand. Reinforcements used existing units, regular movement and actual damage/visible threat reports. The diagnostic assigned AI control to the normal human slot only for this offline test.

CPU-only ticks had a **6.57 ms median**, **16.38 ms p95** and **85.09 ms maximum**. A separate 200-tick replay reduced the median from **11.35 to 6.29 ms** after spatial/drop-off/fog/victory optimizations. These are simulation timings, not rendered FPS. The match logged numerous blocked orders, particularly in crowded settlements; movement recovery and long-match routing still need further review. Record: `artifacts/battle-benchmark-highlands.json`.

## Crowded-battle performance

`scripts/performance-qa.mjs` restores the same earlier 780-second Huge battle, with approximately 330 surviving troops. Presets run sequentially in headless Edge, automatic quality off, with actual Intel UHD graphics through ANGLE. Render submissions and displayed-frame cadence are measured over a five-second sample after warmup. The script accepts declared profile/resolution/frame targets and reports whether the target is met; it can enforce a target as a separate acceptance gate. This machine is not the reference for every player's hardware.

| Earlier preset, 1280 x 720 | Rendered FPS | Draw calls | Render submission median | Simulation tick median |
|---|---:|---:|---:|---:|
| Low | 17.0 | 294 | 21.9 ms | 24.7 ms |
| High | 8.4 | 308 | 34.9 ms | 26.6 ms |

Both current samples miss the selected 60 FPS target. Earlier 1280 x 800 measurements were Low 19.2/High 12.1 FPS; a prior Low baseline submitted 942 draws at 13.7 FPS. The immediately preceding 1280 x 720 sample measured Low 14.5/High 14.0 FPS. These short runs vary substantially and cannot establish sustained gains; the latest High scene also has richer foliage. High remains unsuitable for this approximately 4 GB Intel UHD laptop's crowded battles. This is not a physical-phone result or evidence of broad compatibility. Files: `artifacts/performance-qa.json`, `artifacts/performance-before-partial-uploads.json`, `artifacts/performance-before-shared-batches.json`, `artifacts/render-profile.json` and late-battle screenshots. Continue optimization and defined physical-device acceptance testing.

## Remaining release work

Continue crowded-scene CPU/GPU optimization and movement recovery; verify sustained play on defined physical phones/laptops; and obtain human difficulty, mission-pacing and usability feedback. Public hosting has not been deployed. Rooms are in server memory, and public matchmaking/persistent rooms/accounts are not implemented. The implemented original 3D game is a beta; overall AAA/world-class parity and compatibility with every device have not been established.

# Archived version 2.4 verification

Checked 10 October 2026. This records observed checks, rather than a claim that all possible bugs or all device configurations have been ruled out.

## Automated game checks

`npm test`: **118 passed, zero failed**. Coverage includes paid gathering/construction/training/research; ages and civilization restrictions; counters, healing and siege; walls, gates and bridges; fleets and transports; all modes and staged campaigns; checkpoints and save compatibility; production batches; custom alliances, large-map fog/navigation/picking, each victory rule, independent AI clocks, seeded weather, real WebSocket rooms, shore-aware invasion targets, fleet population reserves, visible work animations, solid cargo/tree transforms, secure hosted endpoints and canceled reconnect timers.

Eight simultaneous real WebSocket clients exercised readiness, private economies and fog, command ownership, reconnect recovery, host elimination and alliance results. Mixed human/AI rooms also passed. These tests use isolated services and do not modify live player rooms.

## Custom battle and 3D checks

`scripts/custom-battle-qa.mjs` passed in a real Edge renderer with desktop and emulated landscape-phone layouts:

- Huge 400 × 400 battlefield, eight kingdoms, independent AI difficulty and eight army materials.
- Actual terrain clicks beyond the former ±160 picking limit and full-map radar navigation.
- Deferred unseen-mesh allocation, persistent objective scrolling/rules, and custom save/resume with a paid training queue.
- Volumetric rain with three effect draw calls; quality-limited snow, weather settings and optional lightning.
- Square minimap, touch interaction and no horizontal page overflow at 844 × 390.

`scripts/custom-multiplayer-qa.mjs` passed with desktop and phone-sized browsers, a third real WebSocket commander and an AI kingdom: guest slot choice, host/guest readiness, private local perspectives, rejected foreign commands, phone production, reload/rejoin, host defeat without ending the match, and correct alliance victory/defeat.

The machine reports approximately 4 GB RAM. Three simultaneous 3D browser contexts timed out without a JavaScript error; a later two-renderer run also timed out during startup. The current mixed-room check keeps two browser connections, suspends rendering in the background desktop host, actively renders the landscape-phone client, and connects a third real WebSocket commander. This is not a simultaneous multi-device FPS measurement. Failed attempts remain recorded in the browser report. A reconnect assertion was corrected to count both queued and completed paid units in the received resume state, because production can finish while a cold browser redraws.

`scripts/interactions-qa.mjs` passed actual harvesting, carried logs/sacks/ingots/rocks, tree falls and persistent stumps, ore depletion, one-time town-center model replacement per age change, huge-map fog/grass coverage and landscape-phone camera interaction. The scene contains no sprites. Four repeated Huge winter matches held GPU counts at **245 geometries and 11 textures** in this fixture. Cargo/stumps used at most five extra draw calls. This follows Three.js's [explicit resource disposal guidance](https://threejs.org/manual/pages/how-to-dispose-of-objects.html) and [mesh batching guidance](https://threejs.org/manual/pages/optimize-lots-of-objects.html).

## Full-match diagnostic

`scripts/battle-benchmark.mjs`, seed 512, Huge highlands, eight Hard AI kingdoms, standard resources and an 80-person cap:

- Started with the normal economy. The diagnostic alone assigned AI control to the normal human slot.
- All kingdoms reached Imperial Age. The winning alliance eliminated every opposing building through normal production and combat, finishing at **977.4 simulated seconds** (about 16 minutes).
- CPU-only simulation tick times: median **10.44 ms**, p95 **21.24 ms**, p99 **30.10 ms**, maximum **65.68 ms** on this run. These are simulation timings, not rendered FPS or phone timings.
- An earlier pre-optimization match also reached a normal result after about 29 simulated minutes. Battle length is situational, without a forced minimum timer.

Recorded artifacts include `artifacts/battle-benchmark-highlands.json`, the earlier baseline/pre-route-cache reports, custom browser JSON reports and screenshots.

The expanded coastal audit initially exposed stalled cross-shore orders, repeated harbor losses and fleet recruitment starvation. After the fixes, the eight-Hard-AI Huge coast diagnostic reached normal all-building victory at **1138.8 simulated seconds** (about 19 minutes), with all kingdoms reaching Imperial Age. It used standard starting resources, paid production and actual combat. The earlier fleet-fix run also reached victory at 778.5 seconds; flanking strategy changed the final battle's course. The final report is `artifacts/battle-benchmark-coast.json`, with failed/stalled earlier runs retained separately. It ran alongside browser checks on this low-memory machine: median tick 12.86 ms, p95 73.86 ms and a 2.51-second maximum under contention. These timings are not a standalone performance baseline or evidence of smooth phone FPS.

## Corrections made during the audit

Corrected outer-map picking, resource/harbor overlap, coastal resource access, final-load delivery after deposits/shoals are exhausted, sustained AI attack orders, final-building visibility for AI, naval boarding reservations, individual AI ownership/budgets, private research/error notices and objective scroll resets. Added straight-route checks, connected movement regions, reusable path buffers, valid-route retention, blocked-order retry limits, vision indexing and shared composition calculations. Low quality and background/menu rendering budgets reduce work; saved graphics preferences remain respected.

Further corrections include harbor rebuilding without free resources, market trade recovery at the real price threshold, current-shore army orders and retreats, legal capital scouting, searches after clearing a capital, canceled-voyage retries, formation-safe unloading beside occupied harbors, reserved fleet population, transport replacement priority, fuller siege/healer invasion crews and flanking shores chosen from observed defenses. Cargo now uses current interpolated unit positions; town-center age metadata survives batching, and allied units open modeled gate portcullises.

Live selected-object health/cargo and production countdowns now update in place. Production buttons and portrait canvases remain attached until the selection or available actions change, avoiding interrupted taps when a network snapshot updates the UI. A browser regression checks the actual training-button identity across health/timer changes while its health text and queue progress continue updating.

## Hosting preparation

The included `render.yaml` selects one **Free** Node web service in Singapore, with a health check and one simultaneous room for the small server. No expiring database or paid service is provisioned. `netlify.toml` also supports a static frontend with an optional separate secure multiplayer URL and exact server origin permissions. See [DEPLOYMENT.md](DEPLOYMENT.md) for the short setup and verified provider limits. No public site has been deployed from this workspace.

`scripts/deployment-qa.mjs` passed two isolated production builds: static solo/custom play, readable unavailable-multiplayer notices, no broken socket attempts and offline reload; then a separate frontend/backend with a configured endpoint, accepted exact origin and real WebSocket room creation. Offline manifests now follow the configured build output directory rather than accidentally using another build's assets. The report is `artifacts/deployment-qa.json`.

## Further release evidence

Ten broader browser checks and the affected reruns passed: edge scrolling, square radar, production, commander controls/tactics/technology tree, campaign checkpoint flows, solid 3D models across biomes, world interactions, custom setup/weather, offline reload/play, and custom multiplayer. The consolidated report is `artifacts/release-browser-checks.json`; failed attempts are preserved in each affected check's history. The final production/multiplayer rerun is also in `artifacts/production-stability-checks.json`. The running server was restarted with the final source after verifying that no player connections were active; its HTTP version 2.4 bundle, WebSocket ping and hosting health check passed at the laptop and Wi-Fi address. See `artifacts/live-server-check.json`. The current local addresses are `http://localhost:4173/` and `http://192.168.1.6:4173/` on the same Wi-Fi.

Physical phone/laptop FPS, sustained thermal/memory behavior, human balance and mission pacing, and delayed/lossy network play still need independent testing. Public matchmaking, persistent server rooms, accounts, professional authored assets and voice acting are outside this implemented local release. The game is an original playable RTS beta; commercial AAA parity or “100% world class” has not been established.
