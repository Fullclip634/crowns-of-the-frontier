import {spawn} from 'node:child_process';
import {mkdir,stat,writeFile} from 'node:fs/promises';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

const project=fileURLToPath(new URL('../../',import.meta.url));
const tools=path.join(project,'.tools');
const blender=process.env.BLENDER_BIN||path.join(tools,'blender-4.5.14-windows-x64','blender.exe');
const optimizer=process.env.GLTFPACK_BIN||path.join(tools,'gltfpack','gltfpack.exe');
await stat(blender);await stat(optimizer);
await mkdir(path.join(project,'src','assets3d'),{recursive:true});
await mkdir(path.join(tools,'art-refined'),{recursive:true});
const env={...process.env,BLENDER_USER_CONFIG:path.join(tools,'blender-profile','config'),BLENDER_USER_SCRIPTS:path.join(tools,'blender-profile','scripts')};

async function run(command,args,log){
  await new Promise((resolve,reject)=>{
    const output=log?fs.openSync(log,'w'):null;
    const child=spawn(command,args,{cwd:project,env,windowsHide:true,stdio:output===null?'inherit':['ignore',output,output]});
    child.on('error',error=>{if(output!==null)fs.closeSync(output);reject(error);});
    child.on('exit',code=>{if(output!==null)fs.closeSync(output);code===0?resolve():reject(new Error(`${path.basename(command)} failed (${code}); inspect ${log||'the console'}.`));});
  });
}
console.log('Exporting the complete source catalogue.');
await run(process.execPath,['scripts/blender/export-source.mjs']);
console.log('Authoring and refining the game models in Blender.');
await run(blender,['--background','--python-exit-code','1','--python','scripts/blender/refine-catalogue.py'],path.join(tools,'art-refine.log'));
for(const [name,ratio]of [['near','0.82'],['low','0.55']]){
  console.log(`Optimizing the ${name} catalogue.`);
  await run(optimizer,['-i',`.tools/art-refined/frontier-${name}.glb`,'-o',`src/assets3d/frontier-${name}.glb`,
    '-cc','-kn','-km','-ke','-kv','-vpf','-vtf','-si',ratio,'-r',`.tools/art-refined/${name}-optimized.json`]);
}
const source=JSON.parse(fs.readFileSync(path.join(tools,'art-source','catalogue.json'),'utf8'));
const sizes={};for(const name of ['near','low'])sizes[name]=(await stat(path.join(project,'src','assets3d',`frontier-${name}.glb`))).size;
await writeFile(path.join(project,'src','assets3d','catalogue.json'),`${JSON.stringify({models:source,sizes,source:'Original Crowns of the Frontier assets authored/refined in Blender.'},null,2)}\n`);
console.log(JSON.stringify({models:source.length,bytes:sizes}));
