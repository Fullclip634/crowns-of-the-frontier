"""Original Blender art pass: solid foliage, roof tiles, bevels and baked shading.

Run with the project Blender executable in background mode after export-source.
The output retains the game's semantic materials, joints and moving subgroups.
"""

import bpy
import bmesh
import json
import math
import random
from pathlib import Path
from mathutils import Vector, Matrix
from mathutils.bvhtree import BVHTree

project = Path(__file__).resolve().parents[2]
source = project / ".tools/art-source/catalogue.glb"
out = project / ".tools/art-refined"
out.mkdir(parents=True, exist_ok=True)
bpy.ops.object.select_all(action="SELECT")
bpy.ops.object.delete(use_global=False)
bpy.ops.import_scene.gltf(filepath=str(source))
roots = [obj for obj in bpy.data.objects if obj.get("assetKey")]
materials = {}
for obj in bpy.data.objects:
    if obj.type == "MESH" and obj.get("assetMaterial"):
        materials.setdefault(obj["assetMaterial"], obj.data.materials[0])

def descendants(root):
    result = []
    def visit(obj):
        result.append(obj)
        for child in obj.children:
            visit(child)
    visit(root)
    return result

def make_mesh(root, role, vertices, faces, label):
    mesh = bpy.data.meshes.new(label)
    mesh.from_pydata(vertices, [], faces)
    mesh.update()
    obj = bpy.data.objects.new(label, mesh)
    bpy.context.collection.objects.link(obj)
    obj.parent = root
    obj["assetMaterial"] = role
    obj.data.materials.append(materials[role])
    # Planar/organic primitives receive usable UVs even with no bitmap texture.
    uv = mesh.uv_layers.new(name="UVMap")
    for loop in mesh.loops:
        p = mesh.vertices[loop.vertex_index].co
        uv.data[loop.index].uv = (p.x * .25, p.z * .25 + p.y * .1)
    return obj

def rod_data(vertices, faces, start, end, radius, taper=.45, sides=7):
    a, b = Vector(start), Vector(end)
    direction = (b - a).normalized()
    u = direction.cross(Vector((0, 0, 1)))
    if u.length < .001:
        u = direction.cross(Vector((0, 1, 0)))
    u.normalize()
    v = direction.cross(u).normalized()
    base = len(vertices)
    for center, r in [(a, radius), (b, radius * taper)]:
        for i in range(sides):
            angle = i * math.tau / sides
            vertices.append(tuple(center + (u * math.cos(angle) + v * math.sin(angle)) * r))
    faces.append(tuple(base + i for i in range(sides - 1, -1, -1)))
    faces.append(tuple(base + sides + i for i in range(sides)))
    for i in range(sides):
        j = (i + 1) % sides
        faces.append((base + i, base + j, base + sides + j, base + sides + i))

def organic_crown(vertices, faces, center, scale, rng, detail):
    bm = bmesh.new()
    bmesh.ops.create_icosphere(bm, subdivisions=detail, radius=1)
    bm.verts.ensure_lookup_table()
    base = len(vertices)
    for vert in bm.verts:
        p = vert.co
        noise = 1 + .12 * math.sin(p.x * 5 + p.y * 3) + rng.uniform(-.055, .055)
        vertices.append((center[0] + p.x * scale[0] * noise,
                         center[1] + p.y * scale[1] * noise,
                         center[2] + p.z * scale[2] * noise))
    for face in bm.faces:
        faces.append(tuple(base + vert.index for vert in face.verts))
    bm.free()

def leaf_volume(vertices, faces, center, direction, length, width, thickness=.025):
    """A pointed leaf with a raised vein and a closed underside, not a card."""
    center, axis = Vector(center), Vector(direction).normalized()
    across = axis.cross(Vector((0, 0, 1)))
    if across.length < .01:
        across = axis.cross(Vector((0, 1, 0)))
    across.normalize()
    normal = across.cross(axis).normalized()
    base = len(vertices)
    vertices.extend(tuple(point) for point in [center + axis*length*.5,
        center + across*width, center - axis*length*.5, center - across*width,
        center + normal*thickness, center - normal*thickness])
    for i in range(4):
        j = (i+1) % 4
        faces.extend([(base+j, base+i, base+4), (base+i, base+j, base+5)])

def crown_leaves(root, crowns, scale, rng):
    for parity, role in [(0, "leaf"), (1, "leafDark")]:
        vertices, faces = [], []
        for i, center in enumerate(crowns):
            if i % 2 != parity:
                continue
            # Stable surface distribution with different tilt/size at each tip.
            for j in range(64):
                z = 1 - 2*(j+.5)/64
                angle = j*2.399963 + rng.uniform(-.16, .16)
                radius = math.sqrt(max(0, 1-z*z))
                direction = Vector((radius*math.cos(angle), radius*math.sin(angle), z))
                position = Vector(center) + Vector(tuple(direction[k]*scale[k]*1.10 for k in range(3)))
                tilt = Vector((math.cos(angle+.7), math.sin(angle+.7), rng.uniform(-.45, .35)))
                leaf_volume(vertices, faces, position, tilt, rng.uniform(.34, .55), rng.uniform(.10, .18))
        if vertices:
            obj = make_mesh(root, role, vertices, faces, root.name + "_LeafTips_" + role)
            obj["nearOnly"] = True
            obj["foliageDetail"] = "closed leaf tips"

def winter_boughs(root, height, variant, far, rng):
    bark_vertices, bark_faces = [], []
    foliage = {role: ([], []) for role in ["leafDark", "snow"]}
    tiers, branches = (5, 7) if far else (7, 9)
    for tier in range(tiers):
        z = 1.5 + tier*(height-1.9)/(tiers-1)
        radius = 2.15*(1-tier/(tiers+1))
        for branch in range(branches):
            angle = branch*math.tau/branches + tier*.43 + variant*.3
            direction = Vector((math.cos(angle), math.sin(angle), 0))
            root_point = Vector((.10, -.05, z))
            tip = root_point + direction*(radius*rng.uniform(.88, 1.1)) + Vector((0, 0, -.22))
            rod_data(bark_vertices, bark_faces, root_point, tip, .075*(1-tier/tiers*.65), .12, 5 if far else 7)
            for section in range(2 if far else 3):
                fraction = .30 + section*(.55 if far else .30)
                center = root_point.lerp(tip, fraction)
                length = radius*(.7 if far else .55)
                width = radius*(.22 if far else .18)*(1-section*.12)
                verts, faces = foliage["leafDark"]
                leaf_volume(verts, faces, center, direction, length, width, .13 if far else .11)
                # Uneven patches sit on the boughs, leaving dark needle edges.
                if (branch+tier+variant) % 3 != 0:
                    verts, faces = foliage["snow"]
                    leaf_volume(verts, faces, center+Vector((0, 0, .125)), direction,
                                length*.72, width*.68, .06)
    make_mesh(root, "trunk", bark_vertices, bark_faces, root.name + "_Boughs")
    for role, (vertices, faces) in foliage.items():
        make_mesh(root, role, vertices, faces, root.name + "_" + role)

def author_tree(root):
    _, biome, variant, lod = root["assetKey"].split(":")
    variant = int(variant)
    rng = random.Random(2201 + variant)
    far = lod == "far"
    for obj in reversed(descendants(root)[1:]):
        bpy.data.objects.remove(obj, do_unlink=True)
    vertices, faces = [], []
    height, spread = [(6.3, 1.0), (7.2, .78), (6.5, 1.18), (5.8, 1.12)][variant]
    if biome == "winter":
        height, spread = 5.8 + variant*.15, 1.0
    elif biome == "desert":
        spread *= .85
    root["foliageSpecies"] = "pine" if biome == "winter" else ["oak", "birch", "elm", "beech"][variant]
    # A gently bent, tapering trunk avoids the straight toy-cylinder silhouette.
    trunk = [(0, 0, 0), (.06, -.025, height*.28),
             (.13+variant*.025, -.06, height*.56), (.18, -.10, height*.80)]
    radii = [.28, .235, .17, .105]
    for segment in range(len(trunk)-1):
        rod_data(vertices, faces, trunk[segment], trunk[segment+1], radii[segment],
                 radii[segment+1]/radii[segment], 8 if far else 13)
    for i in range(4 if not far else 2):
        angle = i * math.tau / 4 + variant
        rod_data(vertices, faces, (0, 0, .35),
                 (math.cos(angle) * .72, math.sin(angle) * .72, .035), .15, .22)
    if biome == "winter":
        make_mesh(root, "trunk", vertices, faces, root.name + "_Bark")
        winter_boughs(root, height, variant, far, rng)
        return
    crowns = []
    for i in range(3 if far else 16):
        angle = i * 2.399 + variant
        tier = (i-1) % 3 if i else 0
        radius = ((.82+rng.random()*.28) if far else (.55+tier*.45+rng.random()*.25))*spread if i else .10
        location = (math.cos(angle) * radius, math.sin(angle) * radius,
                    height - (.30 if not i else .60+tier*.65))
        junction = (.13, -.06, height*.50)
        bend = ((junction[0]+location[0])*.5, (junction[1]+location[1])*.5, height*.70)
        rod_data(vertices, faces, junction, bend, .10, .6, 7 if far else 10)
        rod_data(vertices, faces, bend, location, .06, .25, 6 if far else 9)
        crowns.append(location)
    make_mesh(root, "trunk", vertices, faces, root.name + "_Bark")
    scale = ((1.4 if far else .92)*spread, (1.25 if far else .83)*spread,
             (.78 if far else .60) if biome == "desert" else (1.12 if far else .78))
    for parity, role in [(0, "leaf"), (1, "leafDark")]:
        vertices, faces = [], []
        for i, center in enumerate(crowns):
            if i % 2 != parity:
                continue
            # Smooth closed lobes remain the affordable distant canopy.
            organic_crown(vertices, faces, center, scale, rng, 2)
        make_mesh(root, role, vertices, faces, root.name + "_" + role)
    if not far:
        crown_leaves(root, crowns, scale, rng)

def weld(obj):
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    bmesh.ops.remove_doubles(bm, verts=list(bm.verts), dist=.00001)
    bm.normal_update()
    bm.to_mesh(obj.data)
    bm.free()
    obj.data.update()
    if obj.get("assetMaterial") in {"skin", "hair", "pants", "team", "canvas", "leather", "straw", "horse", "mane", "leaf", "leafDark", "trunk", "steel"}:
        for polygon in obj.data.polygons:
            polygon.use_smooth = True
        # Blender 4.5 splits sharp joins while preserving curved skin and cloth.
        obj.data.set_sharp_from_angle(angle=math.radians(55))

def roof_tiles(root):
    key = root["assetKey"]
    if not key.startswith("building:") or ":sun:" in key:
        return
    for roof in [obj for obj in descendants(root) if obj.type == "MESH" and obj.get("assetMaterial") == "teamRoof"]:
        mesh = roof.data
        vertices = [roof.matrix_world @ vert.co for vert in mesh.vertices]
        faces = [tuple(poly.vertices) for poly in mesh.polygons]
        tree = BVHTree.FromPolygons(vertices, faces, all_triangles=False)
        minx, maxx = min(v.x for v in vertices), max(v.x for v in vertices)
        miny, maxy = min(v.y for v in vertices), max(v.y for v in vertices)
        top = max(v.z for v in vertices) + 1
        tile_vertices, tile_faces = [], []
        count = 0
        y = miny + .28
        while y < maxy - .15 and count < 140:
            x = minx + .29
            while x < maxx - .15 and count < 140:
                point, normal, _, _ = tree.ray_cast(Vector((x, y, top)), Vector((0, 0, -1)))
                if point is not None and .3 < normal.z < .95:
                    tangent = Vector((0, 1, 0))
                    tangent = (tangent - normal * tangent.dot(normal)).normalized()
                    across = tangent.cross(normal).normalized()
                    base = len(tile_vertices)
                    for depth in [0, .035]:
                        for a, b in [(-.285, -.235), (.285, -.235), (.285, .235), (-.285, .235)]:
                            tile_vertices.append(tuple(point + across * a + tangent * b + normal * (depth + .006)))
                    tile_faces.extend([(base,base+3,base+2,base+1),(base+4,base+5,base+6,base+7),
                                       (base,base+1,base+5,base+4),(base+1,base+2,base+6,base+5),
                                       (base+2,base+3,base+7,base+6),(base+3,base,base+4,base+7)])
                    count += 1
                x += .6
            y += .49
        if tile_vertices:
            obj = make_mesh(root, "teamRoof", tile_vertices, tile_faces, root.name + "_SlateTiles")
            obj["nearOnly"] = True

def bake_shading(root):
    meshes = [obj for obj in descendants(root) if obj.type == "MESH"]
    vertices, faces = [], []
    for obj in meshes:
        base = len(vertices)
        vertices.extend(obj.matrix_world @ vert.co for vert in obj.data.vertices)
        faces.extend(tuple(base + v for v in poly.vertices) for poly in obj.data.polygons)
    tree = BVHTree.FromPolygons(vertices, faces, all_triangles=False)
    is_unit = root["assetKey"].startswith("unit:")
    distance = .65 if is_unit else 1.6
    for obj in meshes:
        mesh = obj.data
        old = mesh.color_attributes.get("BakedDepth")
        if old:
            mesh.color_attributes.remove(old)
        colors = mesh.color_attributes.new(name="BakedDepth", type="FLOAT_COLOR", domain="POINT")
        mesh.color_attributes.active_color = colors
        matrix, normal_matrix = obj.matrix_world, obj.matrix_world.to_3x3().inverted().transposed()
        for vert in mesh.vertices:
            p = matrix @ vert.co
            normal = (normal_matrix @ vert.normal).normalized()
            u = normal.cross(Vector((0, 0, 1)))
            if u.length < .01:
                u = normal.cross(Vector((0, 1, 0)))
            u.normalize()
            v = normal.cross(u).normalized()
            occlusion = 0
            for direction in [normal, (normal + u * .8).normalized(),
                              (normal - u * .8).normalized(), (normal + v * .8).normalized()]:
                hit, _, _, dist = tree.ray_cast(p + normal * .018, direction, distance)
                if hit is not None:
                    occlusion += 1 - dist / distance
            shade = max(.64, 1 - occlusion * .075)
            role = obj.get("assetMaterial")
            if role in ["leaf", "leafDark"]:
                # Subtle canopy variation survives compression and batching.
                variation = .90 + .10*(.5+.5*math.sin(p.x*8.1+p.y*5.3+p.z*6.7))
                colors.data[vert.index].color = (shade*variation*.96, shade*variation, shade*variation*.92, 1)
            else:
                colors.data[vert.index].color = (shade, shade, shade, 1)

exec(compile((project / "scripts/blender/human-figures.py").read_text(encoding="utf-8"), "human-figures.py", "exec"))

for i, root in enumerate(roots):
    if root["assetKey"].startswith("unit:"):
        author_human(root)
    if root["assetKey"].startswith("tree:"):
        author_tree(root)
    for obj in descendants(root):
        if obj.type == "MESH":
            weld(obj)
    roof_tiles(root)
    bpy.context.view_layer.update()
    bake_shading(root)
    if (i + 1) % 12 == 0:
        print(f"Refined {i + 1}/{len(roots)} models", flush=True)

def export(name, near):
    bpy.ops.object.select_all(action="DESELECT")
    selected = []
    for root in roots:
        for obj in descendants(root):
            if not near and obj.get("nearOnly"):
                continue
            obj.select_set(True)
            selected.append(obj)
    if near:
        for obj in selected:
            if obj.type != "MESH" or obj.get("assetMaterial") in ["leaf", "leafDark", "snow"]:
                continue
            bpy.context.view_layer.objects.active = obj
            bevel = obj.modifiers.new("Crafted edges", "BEVEL")
            bevel.width = .009 if obj.get("motion") else .023
            bevel.segments = 1
            bevel.limit_method = "ANGLE"
            bevel.angle_limit = .8
            bevel.use_clamp_overlap = True
    bpy.ops.export_scene.gltf(filepath=str(out / name), export_format="GLB",
                             use_selection=True, export_apply=True,
                             export_vertex_color="ACTIVE",
                             export_extras=True, export_animations=False,
                             export_cameras=False, export_lights=False)

export("frontier-low.glb", False)
export("frontier-near.glb", True)
bpy.ops.wm.save_as_mainfile(filepath=str(out / "frontier-assets.blend"), compress=True)
(out / "report.json").write_text(json.dumps({"models": len(roots), "source": "original game assets and authored Blender geometry",
                                             "features": ["civic arcades", "detailed gables", "field packs and visors", "species-shaped crowns", "curved tapered trunks", "closed leaf tips", "branched winter boughs", "patchy snow", "smooth volumetric foliage", "adult figures", "nested joints", "solid worker tools", "slate tiles", "beveled edges", "baked vertex shading"]}, indent=2), encoding="utf-8")
print("Blender catalogue art pass complete.", flush=True)
