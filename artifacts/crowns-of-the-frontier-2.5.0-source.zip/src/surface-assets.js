import * as THREE from 'three';

const files={
  grass:{color:new URL('./assets3d/textures/leafy_grass_color.jpg',import.meta.url).href,normal:new URL('./assets3d/textures/leafy_grass_normal.jpg',import.meta.url).href,arm:new URL('./assets3d/textures/leafy_grass_arm.jpg',import.meta.url).href},
  stone:{color:new URL('./assets3d/textures/medieval_blocks_05_color.jpg',import.meta.url).href,normal:new URL('./assets3d/textures/medieval_blocks_05_normal.jpg',import.meta.url).href,arm:new URL('./assets3d/textures/medieval_blocks_05_arm.jpg',import.meta.url).href},
  wood:{color:new URL('./assets3d/textures/old_wood_floor_color.jpg',import.meta.url).href,normal:new URL('./assets3d/textures/old_wood_floor_normal.jpg',import.meta.url).href,arm:new URL('./assets3d/textures/old_wood_floor_arm.jpg',import.meta.url).href},
  plaster:{color:new URL('./assets3d/textures/painted_plaster_wall_color.jpg',import.meta.url).href,normal:new URL('./assets3d/textures/painted_plaster_wall_normal.jpg',import.meta.url).href,arm:new URL('./assets3d/textures/painted_plaster_wall_arm.jpg',import.meta.url).href},
};
const cache=new Map(),surfaces={};
async function texture(role,kind){
  const key=role+':'+kind;if(!cache.has(key))cache.set(key,new THREE.TextureLoader().loadAsync(files[role][kind]).then(map=>{
    map.colorSpace=kind==='color'?THREE.SRGBColorSpace:THREE.NoColorSpace;map.wrapS=map.wrapT=THREE.RepeatWrapping;map.flipY=false;map.anisotropy=4;
    (surfaces[role]??={})[kind]=map;return map;
  }).catch(error=>{cache.delete(key);throw error;}));return cache.get(key);
}
export async function loadSurfaceAssets(quality){
  const kinds=quality==='high'?['color','normal','arm']:quality==='medium'?['color','normal']:['color'];
  await Promise.all(Object.keys(files).flatMap(role=>kinds.map(kind=>texture(role,kind))));
}
export function surfaceAssetState(){return {source:'Poly Haven CC0',loaded:[...cache.keys()].length};}

export function applySurfaceMaterials(view){
  const m=view.materials,quality=view.settings.quality;
  const bind=(material,role,tint)=>{
    const set=surfaces[role];if(!set?.color||!material)return;
    material.map=set.color;material.bumpMap=null;material.color.setHex(tint);
    material.normalMap=quality==='low'?null:set.normal||null;material.normalScale.setScalar(role==='stone'?.45:.3);
    material.roughnessMap=quality==='high'?set.arm||null:null;material.roughness=.95;material.needsUpdate=true;
  };
  bind(m.stone,'stone',0xe5e0d4);bind(m.brick,'stone',0xb8947b);
  bind(m.plaster,'plaster',0xe5dbbf);
  bind(m.wood,'wood',0xddd1b9);bind(m.darkwood,'wood',0x988674);bind(m.timberEdge,'wood',0x82715d);
  view.surfaceDiagnostics=surfaceAssetState();view.surfaceQuality=quality;
}

export function applyGroundSurface(material,land,quality){
  const set=surfaces.grass;if(!set?.color)return;
  const amount=land.map==='winter'?.16:['desert','canyon'].includes(land.map)?.22:.72;
  // Preserve the seeded biome and roads; photographed detail keeps a consistent
  // physical scale across both small and huge maps.
  material.onBeforeCompile=shader=>{
    shader.uniforms.frontierGroundColor={value:set.color};shader.uniforms.frontierGroundScale={value:land.renderSize/2};shader.uniforms.frontierGroundAmount={value:amount};
    shader.fragmentShader='uniform sampler2D frontierGroundColor;\nuniform float frontierGroundScale;\nuniform float frontierGroundAmount;\n'+shader.fragmentShader;
    shader.fragmentShader=shader.fragmentShader.replace('#include <map_fragment>',`#include <map_fragment>
      vec3 groundDetail = texture2D(frontierGroundColor, vMapUv * frontierGroundScale).rgb;
      float roadMask = smoothstep(0.018, 0.09, diffuseColor.r - diffuseColor.g);
      diffuseColor.rgb = mix(diffuseColor.rgb, groundDetail * 0.85, frontierGroundAmount * (1.0 - roadMask));`);
  };
  material.customProgramCacheKey=()=>`frontier-ground-v1:${land.renderSize}:${amount}`;
  material.userData.surface='Poly Haven leafy grass';
  if(quality!=='low'&&set.normal){material.bumpMap?.dispose();material.bumpMap=null;material.normalMap=set.normal;material.normalMap.repeat.setScalar(land.renderSize/2);material.normalScale.setScalar(.35);}
  if(quality==='high'&&set.arm){material.roughnessMap=set.arm;material.roughnessMap.repeat.setScalar(land.renderSize/2);}
}

export function retainedSurfaceTextures(){return new Set(Object.values(surfaces).flatMap(set=>Object.values(set)));}
