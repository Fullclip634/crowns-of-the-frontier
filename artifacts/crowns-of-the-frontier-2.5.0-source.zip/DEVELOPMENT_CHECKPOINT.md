﻿# Development checkpoint — 11 October 2026

The user's full quality goal remains active. They want an original fully 3D RTS comparable to established top games in visuals, interaction, strategic depth, custom allied AI/human battles, missions, controls and sustained performance. They explicitly authorize continuing Blender/code/research work and do not want questions. Do not claim AAA parity, release readiness, universal-device FPS or overall completion.

## Current local game

Version 2.5.0, Crafted battlefields. Laptop: http://localhost:4173/ . Same Wi-Fi phone: http://192.168.1.3:4173/ . Current production build ID: 1791699374444. The build query can force an initial fresh page. No public deployment is active.

Production Node PID 4432, dev Vite PID 15468 on 4174 at last inspection. Verify exact command lines/listeners and connected clients before any restart. Gameplay AI runs in-browser for offline solo/custom battles; authoritative multiplayer simulation and AI run in the Node backend. Public persistent rooms/matchmaking/accounts are not implemented.

The saved project-owned Blender preview PID 1556 was closed to free authoring memory during sequential browser QA. Detailed editable source: .tools/art-refined/frontier-assets.blend. A fresh lighter preview can be opened with scripts/blender/start.ps1 -Visible -Showcase -LowPreview. This imports the actual low GLB and saves a separate frontier-showcase-low.blend, while keeping High source/runtime detail. Recheck the live process/connector when continuing; do not reuse obsolete PID 1556.

## Latest implemented work

Blender is now reopened as project-owned PID 13724 with frontier-showcase-low.blend. Native MCP handshake/scene/viewport checks succeeded, showing all 126 models and current civic-arcades/field-gear metadata. The current preview uses the smaller catalogue to avoid competing with the game; High runtime detail and editable source remain intact. First handshake briefly reused the old closed socket; the next native request and refreshed status recovered without reinstalling anything.

- Regenerated all 126 Blender assets: 66 building/age/civilization variants, 18 unit/ship/cart types plus four worker tools, 24 trees and 14 resource props. Near/low files: 15,554,824 / 3,639,276 bytes. Low content budget is explicitly 4 MiB, not an FPS target.
- Civic arcades/front steps/facade arches and gable details; worker field packs and armored visors; oak/birch/elm/beech crown proportions; curved trunks, closed High leaf tips and branched winter trees/snow.
- Four verified local CC0 photographed surface sets, including plaster: twelve JPEGs totaling 9,895,943 bytes. Batched buildings preserve roof tile textures and owner colors as well as wood/stone/plaster PBR. High/Medium/Low retain all models.
- Local rendering interpolates between fixed simulation ticks and turns smoothly. Network interpolation is bounded. Authoritative positions, combat timing and saves are preserved.
- Every manifest asset is required at startup. Retry accepts real mouse/touch input and remains present when other downloads finish. WebGL failure leaves start buttons disabled. Production build/version notices save solo matches before refreshing; live human matches block refresh until leaving the room. Pages from before this feature need one initial refresh.
- GPU mesh water waves use analytical normals and expanded bounds, with zero per-frame geometry updates. Terrain banks now meet water level at the actual naval boundary. View-angle-dependent sky tint replaces repeating stripes; it is a lightweight approximation, not full scene reflections.

Preserve existing square radar/rectangular locator, desktop edge/corner scrolling, landscape touch and no movement/path lines. Paid custom AI, allied backup/reserves/recall, long situational matches, large maps and real human rooms remain essential.

## Verification and limitations

Full npm test: 153 passed, zero failed. Production build succeeds. Eight art tests passed separately after fixing roof batching; six map tests verify boundaries/radar/picking. The network timer fixture now freezes only the perspective-test interval, because normal gameplay resets uncaptured sacred-site timers.

Current production authored-art QA passes both catalogues, all seven biomes, navy, worker tools, selection/picking/team colors, bounded corpses/rubble, camera-preserving quality changes and emulated 844x390 landscape controls. High boot 10.6 seconds; settlement 218 draws/1,131,379 triangles. Focused visual-updates QA verifies actual civic/field-gear metadata, roof/plaster textures, deliberate download failure/retry, interpolated render positions without simulation drift, saved refresh and a real-room refresh guard. Battle visual QA passes close High forests, projectile arcs/pooling and cleanup, stable 146 geometries/18 textures. Water QA passes High/Low, 3,915 changed water-only pixels, unchanged CPU geometry, bounds and scene disposal, with no shader errors. Offline checks pass both GLBs/all twelve maps/reload/gameplay. HTTP/WebSocket/health checked 2026-10-11T06:20:06Z; Wi-Fi IP reverified.

Latest crowded 1280x720 Intel UHD headless samples: High 13.48 FPS/305 draws/1.958M triangles before GPU water; Low repeat 12.24 FPS/294 draws/399,532 triangles, 5.065-second sampling window. Both miss the 60 FPS target. This highlands fixture has no water, so it cannot measure the water optimization. An earlier Low sample had a long stall (about 21 seconds, one tick about 14 seconds); retained separately, not a stable comparison. Physical phones/reference gaming laptops and sustained thermal/input/memory behavior remain unverified. Development memory availability is not a game requirement or quality target.

Fresh eight-Hard Huge coastal diagnostic still reaches normal all-building victory after 1276.3 simulated seconds, with 165 allied-support events. Six Imperial/two Castle kingdoms; first land attacks 169.3–230.5 seconds from coastal Feudal start. CPU tick median/p95 4.68/14.24 ms offline. 547 blocked orders remain to investigate by role/order/target. Earlier saved replay reduced blocked orders 23 to 1 after formation recovery. These are bounded scenarios, not universal AI/route completion.

## Continue toward the full goal

1. Profile crowded rendering/simulation and reduce sustained frame times across declared 60/30 FPS reference profiles. Preserve richer High art and complete Low roster; do not define quality by this 4 GB development laptop. Consider moving simulation work off the rendering thread only with authoritative command/save/network coverage.
2. Diagnose blocked coastal routes from actual roles/orders/targets before changing navigation. Preserve paid AI, walls/gates/bridges/transport limits and formation/support behavior.
3. Continue original asset/animation quality, terrain composition/shore resolution, water/ship wakes/rigging, combat/economy interactions, campaign pacing, audio and player usability from QUALITY_TARGETS.md/ROADMAP.md. Current procedural joints are not baked skeletal clips; geometry counts are not a photorealism assessment.
4. Refresh archives after any source/doc change. scripts/package-release.ps1 creates source and static offline/AI ZIPs, excluding .tools/private config/dependencies. Static human multiplayer needs a separate secure backend. Do not promise free hosting forever or no expiry, and do not publicly deploy without a concrete authorized destination.
5. Verify defined physical Android/iOS/laptop hardware and obtain human balance/pacing/usability feedback before declaring release readiness. Keep the full goal active.


